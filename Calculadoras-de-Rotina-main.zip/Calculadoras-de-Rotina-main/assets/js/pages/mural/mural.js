// Imports do Firebase
import { 
    collection,
    getDocs,
    Timestamp,
    deleteDoc,
    doc,
    updateDoc,
    getDoc,
    addDoc,
    query,
    where,
    orderBy,
    writeBatch
} from "https://www.gstatic.com/firebasejs/11.4.0/firebase-firestore.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js";
import { app, auth, db } from "../../../js/firebase.js";

// Imports locais
import { registrarResultadoSN, registrarResultadoELISA, registrarResultadoMolecular, registrarResultadoRAIVA, registrarResultadoICC} from "./regresultado.js";
import { gerarFormularioCobrancaWord } from "../../utils/formularioCobranca.js";

// Firebase centralizado via módulo compartilhado

document.addEventListener('DOMContentLoaded', function() {
    console.log("Desenvolvido por Pedro Ruiz Sangoi e Alexandre Werle Suares, com auxílio do DeepSeek Chat.");
    // Pré-preencher identificação com próximo SV no formulário inline (se existir)
    try { generateSVNumberForField('id'); } catch (e) { console.warn('[SV] Autofill inline indisponível:', e); }
});

// Verificação de usuário ativo/inativo no início
onAuthStateChanged(auth, async (user) => {
    if (!user) {
        window.location.href = "../index.html";
        return;
    }
    
    try {
        const userDoc = await getDoc(doc(db, "usuarios", user.uid));
        if (userDoc.exists()) {
            const userData = userDoc.data();
            if (userData.ativo === false) {
                window.location.href = "desativado.html";
                return;
            }
        }
    } catch (error) {
        console.error("Erro ao verificar status do usuário:", error);
    }
});

// Import functions from shared ui utils to avoid circular imports
import { mostrarLoading, esconderLoading, mostrarFeedback } from './ui-utils.js';
import { adicionarDiasUteis, adicionarDiasCorridos, parseDateInputLocal, obterPrazoDiasTeste } from '../../utils/prazosMural.js';

// Funções auxiliares para datas
function normalizarDataParaUTC(dataString) {
    const dataLocal = new Date(dataString);
    return new Date(Date.UTC(
        dataLocal.getFullYear(),
        dataLocal.getMonth(),
        dataLocal.getDate()
    ));
}

// Prazos (dias úteis/corridos por tipo de teste) ficam em utils/prazosMural.js,
// compartilhados com a ficha SV.

// Função para atualizar prazos de tarefas existentes (executar uma vez)
async function atualizarPrazosExistentes() {
    try {
        // Buscar todas as tarefas para verificar se possuem prazo
        const q = query(collection(db, "tarefas"));
        const querySnapshot = await getDocs(q);
        const batch = writeBatch(db);
        let contador = 0;
        
        querySnapshot.forEach((doc) => {
            const tarefa = doc.data();
            
            // Verificar se a tarefa não possui dataPrazo ou tipoPrazo (tarefas antigas que precisam ser atualizadas)
            if (!tarefa.dataPrazo || !tarefa.tipoPrazo) {
                const prazoInfo = obterPrazoDiasTeste(tarefa.tipo, tarefa.subTipo);
                const dataRecebimento = tarefa.criadoEm?.toDate ? tarefa.criadoEm.toDate() : new Date();
                
                let dataPrazo;
                const delta = Math.max(prazoInfo.dias - 1, 0);
                if (prazoInfo.tipo === 'corridos') {
                    dataPrazo = adicionarDiasCorridos(dataRecebimento, delta);
                } else {
                    dataPrazo = adicionarDiasUteis(dataRecebimento, delta);
                }
                
                batch.update(doc.ref, {
                    dataPrazo: Timestamp.fromDate(dataPrazo),
                    diasPrazo: prazoInfo.dias,
                    tipoPrazo: prazoInfo.tipo
                });
                
                contador++;
            }
        });
        
        if (contador > 0) {
            await batch.commit();
            console.log(`${contador} tarefas atualizadas com prazos`);
            // Remover feedback para não incomodar o usuário quando chamada frequentemente
            // mostrarFeedback(`${contador} tarefas foram atualizadas com informações de prazo`, "info");
        } else {
            console.log("Todas as tarefas já possuem prazos definidos");
        }
        
    } catch (error) {
        console.error("Erro ao atualizar prazos existentes:", error);
    }
}

// Função para calcular e formatar o prazo de uma tarefa
function calcularPrazoTarefa(tarefa) {
    // Priorizar dataRecebimento (editável); fallback para criadoEm
    const dataRecebimento = tarefa.dataRecebimento?.toDate
        ? tarefa.dataRecebimento.toDate()
        : (tarefa.criadoEm?.toDate ? tarefa.criadoEm.toDate() : new Date());
    
    // Se já tem dataPrazo salva, usar ela. Se não, calcular
    let dataPrazo;
    let diasPrazo;
    let tipoPrazo;
    
    if (tarefa.dataPrazo?.toDate) {
        dataPrazo = tarefa.dataPrazo.toDate();
        diasPrazo = tarefa.diasPrazo;
        tipoPrazo = tarefa.tipoPrazo;
        
        // Se não tem informações de tipo de prazo, recalcular baseado no tipo atual
        if (!tipoPrazo) {
            const prazoInfo = obterPrazoDiasTeste(tarefa.tipo, tarefa.subTipo);
            diasPrazo = prazoInfo.dias;
            tipoPrazo = prazoInfo.tipo;
        }
    } else {
        // Calcular prazo se não existir
        const prazoInfo = obterPrazoDiasTeste(tarefa.tipo, tarefa.subTipo);
        diasPrazo = prazoInfo.dias;
        tipoPrazo = prazoInfo.tipo;
        
        const deltaCalc = Math.max(diasPrazo - 1, 0);
        if (tipoPrazo === 'corridos') {
            dataPrazo = adicionarDiasCorridos(dataRecebimento, deltaCalc);
        } else {
            dataPrazo = adicionarDiasUteis(dataRecebimento, deltaCalc);
        }
    }
    
    const hoje = new Date();
    
    // Verificar se está vencido
    const vencido = hoje > dataPrazo;
    
    // Calcular dias restantes
    let diasRestantes = 0;
    if (!vencido) {
        if (tipoPrazo === 'corridos') {
            // Para dias corridos, calcular diferença simples
            const diffTime = dataPrazo.getTime() - hoje.getTime();
            diasRestantes = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        } else {
            // Para dias úteis, contar apenas dias úteis
            let dataTemp = new Date(hoje);
            while (dataTemp < dataPrazo) {
                dataTemp.setDate(dataTemp.getDate() + 1);
                if (dataTemp.getDay() >= 1 && dataTemp.getDay() <= 5) {
                    diasRestantes++;
                }
            }
        }
    }
    
    return {
        dataPrazo,
        diasPrazo,
        tipoPrazo,
        vencido,
        diasRestantes,
        dataRecebimento
    };
}

// Atualizar a função formatarDataParaExibicao para mostrar também a hora
export function formatarDataParaExibicao(dataUTC) {
    return dataUTC.toLocaleDateString("pt-BR", {
        timeZone: "America/Sao_Paulo",
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit"
    });
}

// Obter sigla do usuário
async function getSiglaUsuario(user) {
    try {
        const userRef = doc(db, "usuarios", user.uid);
        const userSnap = await getDoc(userRef);
        
        if (userSnap.exists()) {
            return userSnap.data().sigla || "N/A";
        }
        return "N/A";
    } catch (error) {
        console.error("Erro ao buscar sigla do usuário:", error);
        return "N/A";
    }
}

// ---------------------- SV AutoFill (igual às fichas) ----------------------
async function obterMaiorSVDoAno(yearSuffix) {
    try {
        const tarefasSnapshot = await getDocs(collection(db, 'tarefas'));
        let maiorNumero = 0;
        tarefasSnapshot.forEach(docSnap => {
            const data = docSnap.data();
            const id = (data.id || data.identificacao || data.identificação || '').toString();
            const match = id.match(/SV\s*(\d+)\s*\/\s*(\d{2})/i);
            if (match && match[2] === yearSuffix) {
                const num = parseInt(match[1], 10);
                if (!isNaN(num) && num > maiorNumero) maiorNumero = num;
            }
        });
        return maiorNumero > 0 ? maiorNumero : null;
    } catch (err) {
        console.warn('[SV] Erro ao ler tarefas do mural para SV:', err);
        return null;
    }
}

async function generateSVNumberForField(fieldId) {
    const input = document.getElementById(fieldId);
    if (!input) return;
    const currentYear = new Date().getFullYear();
    const yearSuffix = currentYear.toString().slice(-2);
    const maior = await obterMaiorSVDoAno(yearSuffix);
    if (maior && Number.isInteger(maior)) {
        const proximoNumero = maior + 1;
        const numeroFormatado = proximoNumero.toString().padStart(2, '0');
        input.value = `SV ${numeroFormatado}/${yearSuffix}`;
        localStorage.setItem(`svNumber_${currentYear}`, proximoNumero);
        return;
    }
    // Fallback local
    const svKey = `svNumber_${currentYear}`;
    let svNumber = parseInt(localStorage.getItem(svKey) || '1', 10);
    const numeroFormatado = svNumber.toString().padStart(2, '0');
    input.value = `SV ${numeroFormatado}/${yearSuffix}`;
}

// Funções de Tarefas
async function adicionarTarefaModal() {
    mostrarLoading();
  
    try {
        const user = auth.currentUser;
        if (!user) throw new Error("Usuário não autenticado");

        // Get form elements from modal
        const idInput = document.getElementById("id-modal");
        const tipoInput = document.getElementById("tipo-modal");
        const quantidadeInput = document.getElementById("quantidade-modal");
        const gramaturaInput = document.getElementById("gramatura-modal");
        const pcrTipoInput = document.getElementById("pcr-tipo-modal");
        const snTipoInput = document.getElementById("sn-tipo-modal");
        const elisaTipoInput = document.getElementById("elisa-tipo-modal");
        const alvoInput = document.getElementById("alvo-modal");
        const proprietarioNomeInput = document.getElementById("proprietario-nome-modal");
        const proprietarioMunicipioInput = document.getElementById("proprietario-municipio-modal");
        const proprietarioContatoInput = document.getElementById("proprietario-contato-modal");
        const veterinarioNomeInput = document.getElementById("veterinario-nome-modal");
        const veterinarioCrmvInput = document.getElementById("veterinario-crmv-modal");
        const veterinarioMunicipioInput = document.getElementById("veterinario-municipio-modal");
        const veterinarioContatoInput = document.getElementById("veterinario-contato-modal");
    const observacoesInput = document.getElementById("observacoes-modal");
        const materialRecebidoInput = document.getElementById("material-recebido-modal");
    const dataInput = document.getElementById("data-modal");
    const horaInput = document.getElementById("hora-modal");

        // Validate required fields exist
        if (!idInput || !tipoInput || !quantidadeInput) {
            throw new Error("Campos obrigatórios não encontrados no formulário");
        }

        // Determinar subtipo baseado no tipo principal
        let subTipo = null;
        let alvo = null;
        if (tipoInput.value === "MOLECULAR" && pcrTipoInput) {
            subTipo = pcrTipoInput.value.trim() || null;
            // Capturar alvo apenas para PCR e RT-PCR simples
            if ((subTipo === "PCR" || subTipo === "RT-PCR") && alvoInput) {
                alvo = alvoInput.value.trim() || null;
            }
        } else if (tipoInput.value === "SN" && snTipoInput) {
            subTipo = snTipoInput.value.trim() || null;
        } else if (tipoInput.value === "ELISA" && elisaTipoInput) {
            subTipo = elisaTipoInput.value.trim() || null;
        }

        // Calcular o prazo baseado no tipo de teste
        const prazoInfo = obterPrazoDiasTeste(tipoInput.value, subTipo);

        // Compor data/hora de recebimento a partir dos inputs
        let dataRecebimento = new Date();
        if (dataInput && dataInput.value) {
            // IMPORTANTE: não usar new Date("yyyy-mm-dd") pois cria objeto em UTC 00:00 e no fuso -03 vira dia anterior
            const base = parseDateInputLocal(dataInput.value) || new Date();
            if (horaInput && horaInput.value) {
                const [h, m] = horaInput.value.split(":").map(Number);
                base.setHours(h || 0, m || 0, 0, 0);
            } else {
                base.setHours(0, 0, 0, 0);
            }
            dataRecebimento = base;
        }
        
        let dataPrazo;
        // Cálculo inclusivo: se dias = 15 e data 17 -> prazo final = 17 + (15-1)
        const delta = Math.max(prazoInfo.dias - 1, 0);
        if (prazoInfo.tipo === 'corridos') {
            dataPrazo = adicionarDiasCorridos(dataRecebimento, delta);
        } else {
            dataPrazo = adicionarDiasUteis(dataRecebimento, delta);
        }

        const novaTarefa = {
            id: idInput.value.trim(),
            tipo: tipoInput.value,
            subTipo: subTipo,
            alvo: alvo, // Adicionar campo alvo
            quantidade: parseInt(quantidadeInput.value),
            gramatura: tipoInput.value === "VACINA" && gramaturaInput 
                ? parseFloat(gramaturaInput.value) || null
                : null,
            proprietario: {
                nome: proprietarioNomeInput ? proprietarioNomeInput.value.trim() : "",
                municipio: proprietarioMunicipioInput ? proprietarioMunicipioInput.value.trim() : "",
                contato: proprietarioContatoInput ? proprietarioContatoInput.value.trim() : ""
            },
            veterinario: {
                nome: veterinarioNomeInput ? veterinarioNomeInput.value.trim() : "",
                crmv: veterinarioCrmvInput ? veterinarioCrmvInput.value.trim() : "",
                municipio: veterinarioMunicipioInput ? veterinarioMunicipioInput.value.trim() : "",
                contato: veterinarioContatoInput ? veterinarioContatoInput.value.trim() : ""
            },
            observacoes: observacoesInput ? observacoesInput.value.trim() : "",
            materialRecebido: materialRecebidoInput ? materialRecebidoInput.value.trim() : "",
            status: "pendente",
            // Guardar o recebimento como data de criação (usado em listagens e histórico)
            criadoEm: Timestamp.fromDate(dataRecebimento),
            // Opcional: persistir explicitamente o campo de recebimento
            dataRecebimento: Timestamp.fromDate(dataRecebimento),
            dataPrazo: Timestamp.fromDate(dataPrazo), // Nova data do prazo
            diasPrazo: prazoInfo.dias, // Armazenar dias para referência
            tipoPrazo: prazoInfo.tipo, // Armazenar tipo de prazo (corridos ou úteis)
            criadoPor: user.uid,
            siglaResponsavel: await getSiglaUsuario(user) // Aguarda a busca da sigla
        };

        // Validate required data
        if (!novaTarefa.id) throw new Error("ID é obrigatório");
        if (isNaN(novaTarefa.quantidade)) throw new Error("Quantidade inválida");
        if (novaTarefa.quantidade <= 0) throw new Error("Quantidade deve ser maior que zero");

        // Add to Firestore
        await addDoc(collection(db, "tarefas"), novaTarefa);

        // Atualizar contador local de SV (reserva simples)
        try {
            const currentYear = new Date().getFullYear();
            const yearSuffix = currentYear.toString().slice(-2);
            const match = (novaTarefa.id || '').toString().match(/SV\s*(\d+)\s*\/\s*(\d{2})/i);
            if (match && match[2] === yearSuffix) {
                const svKey = `svNumber_${currentYear}`;
                const num = parseInt(match[1], 10);
                if (!isNaN(num)) localStorage.setItem(svKey, num + 1);
            }
        } catch (e) { console.warn('[SV] Não foi possível atualizar reserva local:', e); }

        // Fechar o modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('tarefa-modal'));
        if (modal) modal.hide();
        
        carregarTarefas();
        mostrarFeedback("Tarefa adicionada com sucesso!", "success");
    } catch (error) {
        console.error("Erro ao adicionar tarefa:", error);
        mostrarFeedback(`Erro: ${error.message}`, "error");
    } finally {
        esconderLoading();
    }
}

// Função para preparar o modal para adicionar tarefa
function prepararModalAdicao() {
    const modal = document.getElementById('tarefa-modal');
    const modalTitle = modal.querySelector('.modal-title');
    const form = document.getElementById('mural-form-modal');
    
    // Configurar título
    modalTitle.innerHTML = '<i class="bi bi-plus-circle"></i> Nova Tarefa';
    
    // Resetar formulário
    form.reset();
    
    // Configurar o botão salvar para adicionar tarefa
    document.getElementById('salvar-tarefa-modal').onclick = adicionarTarefaModal;
    
    // Datas para hoje
    const agora = new Date();
    const yyyy = agora.getFullYear();
    const mm = String(agora.getMonth() + 1).padStart(2, '0');
    const dd = String(agora.getDate()).padStart(2, '0');
    // Evita bug de +1 dia usando valueAsDate (UTC shift). Preenche manualmente.
    document.getElementById('data-modal').value = `${yyyy}-${mm}-${dd}`;
    const horaEl = document.getElementById('hora-modal');
    if (horaEl) {
        const hh = String(agora.getHours()).padStart(2, '0');
        const mm = String(agora.getMinutes()).padStart(2, '0');
        horaEl.value = `${hh}:${mm}`;
    }
    // Sugerir próximo SV como identificação
    try { generateSVNumberForField('id-modal'); } catch (e) { console.warn('[SV] Autofill modal indisponível:', e); }
    
    // Ajustar campos condicionais
    const tipoValue = document.getElementById('tipo-modal').value;
    
    const gramaturaContainer = document.getElementById('gramatura-container-modal');
    if (gramaturaContainer) {
        gramaturaContainer.style.display = tipoValue === "VACINA" ? "block" : "none";
    }
    
    const pcrContainer = document.getElementById('pcr-container-modal');
    if (pcrContainer) {
        pcrContainer.style.display = tipoValue === "MOLECULAR" ? "block" : "none";
    }
    
    const snContainer = document.getElementById('sn-container-modal');
    if (snContainer) {
        snContainer.style.display = tipoValue === "SN" ? "block" : "none";
    }
    
    const elisaContainer = document.getElementById('elisa-container-modal');
    if (elisaContainer) {
        elisaContainer.style.display = tipoValue === "ELISA" ? "block" : "none";
    }
    
    // Configurar menus flutuantes
    try {
        configurarMenusFlutantes();
    } catch (error) {
        console.warn('Erro ao configurar menu PCR:', error);
    }
}

// Função para configurar todos os menus flutuantes
function configurarMenusFlutantes() {
    configurarMenuPCR();
    configurarMenuSN();
    configurarMenuELISA();
    configurarTipoChangeListener();
}

// Função para configurar o listener do tipo de teste
function configurarTipoChangeListener() {
    const tipoModalSelect = document.getElementById('tipo-modal');
    if (!tipoModalSelect || tipoModalSelect.hasAttribute('data-tipo-configured')) {
        return;
    }
    
    tipoModalSelect.setAttribute('data-tipo-configured', 'true');
    
    tipoModalSelect.addEventListener('change', function() {
        const tipoValue = this.value;
        
        // Controlar gramatura (VACINA)
        const gramaturaContainer = document.getElementById('gramatura-container-modal');
        if (gramaturaContainer) {
            gramaturaContainer.style.display = tipoValue === "VACINA" ? "block" : "none";
        }
        
        // Controlar containers dos submenus
        const pcrContainer = document.getElementById('pcr-container-modal');
        const alvoContainer = document.getElementById('alvo-container-modal');
        if (pcrContainer) {
            pcrContainer.style.display = tipoValue === "MOLECULAR" ? "block" : "none";
            if (tipoValue !== "MOLECULAR") {
                const pcrInput = document.getElementById('pcr-tipo-modal');
                if (pcrInput) pcrInput.value = '';
                // Ocultar e limpar campo alvo também
                if (alvoContainer) {
                    alvoContainer.style.display = 'none';
                    const alvoInput = document.getElementById('alvo-modal');
                    if (alvoInput) alvoInput.value = '';
                }
            }
        }
        
        const snContainer = document.getElementById('sn-container-modal');
        if (snContainer) {
            snContainer.style.display = tipoValue === "SN" ? "block" : "none";
            if (tipoValue !== "SN") {
                const snInput = document.getElementById('sn-tipo-modal');
                if (snInput) snInput.value = '';
            }
        }
        
        const elisaContainer = document.getElementById('elisa-container-modal');
        if (elisaContainer) {
            elisaContainer.style.display = tipoValue === "ELISA" ? "block" : "none";
            if (tipoValue !== "ELISA") {
                const elisaInput = document.getElementById('elisa-tipo-modal');
                if (elisaInput) elisaInput.value = '';
            }
        }
    });
}
function configurarMenuPCR() {
    const pcrTipoInput = document.getElementById('pcr-tipo-modal');
    const pcrFloatingMenu = document.getElementById('pcr-floating-menu');
    const alvoContainer = document.getElementById('alvo-container-modal');
    
    // Verificar se todos os elementos existem
    if (!pcrTipoInput || !pcrFloatingMenu) {
        console.warn('Elementos PCR não encontrados. Funcionalidade PCR pode não funcionar corretamente.');
        return;
    }
    
    // Verificar se já foi configurado
    if (pcrTipoInput.hasAttribute('data-pcr-configured')) {
        return;
    }
    
    pcrTipoInput.setAttribute('data-pcr-configured', 'true');
    
    // Configurar eventos do menu flutuante PCR
    pcrTipoInput.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        const rect = this.getBoundingClientRect();
        
        // Usar posição fixed
        pcrFloatingMenu.style.position = 'fixed';
        pcrFloatingMenu.style.top = rect.bottom + 'px';
        pcrFloatingMenu.style.left = rect.left + 'px';
        pcrFloatingMenu.style.width = rect.width + 'px';
        pcrFloatingMenu.style.zIndex = '9999';
        pcrFloatingMenu.classList.add('show');
    });
    
    // Configurar clicks nos items do menu
    if (!pcrFloatingMenu.hasAttribute('data-pcr-configured')) {
        pcrFloatingMenu.setAttribute('data-pcr-configured', 'true');
        
        pcrFloatingMenu.addEventListener('click', function(e) {
            if (e.target.classList.contains('pcr-menu-item')) {
                const value = e.target.getAttribute('data-value');
                pcrTipoInput.value = value;
                
                // Remover seleção anterior
                document.querySelectorAll('.pcr-menu-item').forEach(item => {
                    item.classList.remove('selected');
                });
                
                // Adicionar seleção atual
                e.target.classList.add('selected');
                
                // Mostrar/ocultar campo alvo baseado na seleção
                if (alvoContainer) {
                    if (value === 'PCR' || value === 'RT-PCR') {
                        alvoContainer.style.display = 'block';
                        // Focar no campo alvo para facilitar o preenchimento
                        setTimeout(() => {
                            const alvoInput = document.getElementById('alvo-modal');
                            if (alvoInput) alvoInput.focus();
                        }, 100);
                    } else {
                        alvoContainer.style.display = 'none';
                        // Limpar o campo alvo se não for PCR simples
                        const alvoInput = document.getElementById('alvo-modal');
                        if (alvoInput) alvoInput.value = '';
                    }
                }
                
                // Fechar menu
                pcrFloatingMenu.classList.remove('show');
            }
        });
        
        // Fechar menu ao clicar fora
        document.addEventListener('click', function(e) {
            if (!pcrTipoInput.contains(e.target) && !pcrFloatingMenu.contains(e.target)) {
                pcrFloatingMenu.classList.remove('show');
            }
        });
    }
}

// Função para configurar o menu flutuante de SN
function configurarMenuSN() {
    const snTipoInput = document.getElementById('sn-tipo-modal');
    const snFloatingMenu = document.getElementById('sn-floating-menu');
    
    if (!snTipoInput || !snFloatingMenu) {
        return;
    }
    
    if (!snTipoInput.hasAttribute('data-sn-configured')) {
        snTipoInput.setAttribute('data-sn-configured', 'true');
        
        snTipoInput.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const rect = this.getBoundingClientRect();
            snFloatingMenu.style.position = 'fixed';
            snFloatingMenu.style.top = rect.bottom + 'px';
            snFloatingMenu.style.left = rect.left + 'px';
            snFloatingMenu.style.width = rect.width + 'px';
            snFloatingMenu.style.zIndex = '9999';
            snFloatingMenu.classList.add('show');
        });
    }
    
    if (!snFloatingMenu.hasAttribute('data-sn-configured')) {
        snFloatingMenu.setAttribute('data-sn-configured', 'true');
        
        snFloatingMenu.addEventListener('click', function(e) {
            if (e.target.classList.contains('sn-menu-item')) {
                const value = e.target.getAttribute('data-value');
                snTipoInput.value = value;
                
                document.querySelectorAll('.sn-menu-item').forEach(item => {
                    item.classList.remove('selected');
                });
                
                e.target.classList.add('selected');
                snFloatingMenu.classList.remove('show');
            }
        });
        
        document.addEventListener('click', function(e) {
            if (!snTipoInput.contains(e.target) && !snFloatingMenu.contains(e.target)) {
                snFloatingMenu.classList.remove('show');
            }
        });
    }
}

// Função para configurar o menu flutuante de ELISA
function configurarMenuELISA() {
    const elisaTipoInput = document.getElementById('elisa-tipo-modal');
    const elisaFloatingMenu = document.getElementById('elisa-floating-menu');
    
    if (!elisaTipoInput || !elisaFloatingMenu) {
        return;
    }
    
    if (!elisaTipoInput.hasAttribute('data-elisa-configured')) {
        elisaTipoInput.setAttribute('data-elisa-configured', 'true');
        
        elisaTipoInput.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const rect = this.getBoundingClientRect();
            elisaFloatingMenu.style.position = 'fixed';
            elisaFloatingMenu.style.top = rect.bottom + 'px';
            elisaFloatingMenu.style.left = rect.left + 'px';
            elisaFloatingMenu.style.width = rect.width + 'px';
            elisaFloatingMenu.style.zIndex = '9999';
            elisaFloatingMenu.classList.add('show');
        });
    }
    
    if (!elisaFloatingMenu.hasAttribute('data-elisa-configured')) {
        elisaFloatingMenu.setAttribute('data-elisa-configured', 'true');
        
        elisaFloatingMenu.addEventListener('click', function(e) {
            if (e.target.classList.contains('elisa-menu-item')) {
                const value = e.target.getAttribute('data-value');
                elisaTipoInput.value = value;
                
                document.querySelectorAll('.elisa-menu-item').forEach(item => {
                    item.classList.remove('selected');
                });
                
                e.target.classList.add('selected');
                elisaFloatingMenu.classList.remove('show');
            }
        });
        
        document.addEventListener('click', function(e) {
            if (!elisaTipoInput.contains(e.target) && !elisaFloatingMenu.contains(e.target)) {
                elisaFloatingMenu.classList.remove('show');
            }
        });
    }
}

// Função para carregar tarefas
async function carregarTarefas(filtro = "Todos", ordem = "recentes") {
    mostrarLoading();
    try {
        // Atualizar prazos de tarefas existentes silenciosamente
        try {
            await atualizarPrazosExistentes();
        } catch (error) {
            console.warn("Aviso ao atualizar prazos:", error);
        }
        
        const muralList = document.getElementById("mural-list");
        if (!muralList) {
            console.error("Elemento mural-list não encontrado");
            esconderLoading();
            return;
        }

        muralList.innerHTML = "<p>Carregando tarefas...</p>";

        const user = auth.currentUser;
        if (!user) {
            esconderLoading();
            window.location.href = "../index.html";
            return;
        }

        // Verificar conexão com a internet
        if (!navigator.onLine) {
            muralList.innerHTML = '<p class="text-danger">Sem conexão com a internet. Verifique sua conexão e tente novamente.</p>';
            esconderLoading();
            return;
        }

        // Lógica de filtro atualizada para nova estrutura
        let q;
        if (filtro === "Todos") {
            q = query(
                collection(db, "tarefas"),
                orderBy("criadoEm", ordem === "recentes" ? "desc" : "asc")
            );
        } else if (filtro === "SN") {
            // Para SN, incluímos tanto os novos (tipo="SN") quanto os antigos (tipo específico de SN)
            q = query(
                collection(db, "tarefas"),
                orderBy("criadoEm", ordem === "recentes" ? "desc" : "asc")
            );
        } else if (filtro === "ELISA") {
            // Para ELISA, incluímos tanto os novos (tipo="ELISA") quanto os antigos (tipo específico de ELISA)
            q = query(
                collection(db, "tarefas"),
                orderBy("criadoEm", ordem === "recentes" ? "desc" : "asc")
            );
        } else if (filtro === "MOLECULAR") {
            // Para MOLECULAR, incluímos tanto os novos (tipo="MOLECULAR") quanto os antigos (tipo="PCR")
            q = query(
                collection(db, "tarefas"),
                orderBy("criadoEm", ordem === "recentes" ? "desc" : "asc")
            );
        } else {
            // Para outros tipos, filtramos normalmente
            q = query(
                collection(db, "tarefas"),
                where("tipo", "==", filtro),
                orderBy("criadoEm", ordem === "recentes" ? "desc" : "asc")
            );
        }

        const querySnapshot = await getDocs(q);

        if (querySnapshot.empty) {
            muralList.innerHTML = "<p>Nenhuma tarefa encontrada.</p>";
            esconderLoading();
            return;
        }

        muralList.innerHTML = "";
        querySnapshot.forEach((doc) => {
            const tarefa = doc.data();
            
            // Aplicar filtro manual para SN, ELISA e MOLECULAR que incluem dados antigos
            let incluirTarefa = true;
            if (filtro === "SN") {
                incluirTarefa = tarefa.tipo === "SN" || 
                              tarefa.tipo === "SN IBR" || 
                              tarefa.tipo === "SN BVDV-1" ||
                              tarefa.tipo === "SN BVDV-2" ||
                              tarefa.tipo === "SN HoBi" ||
                              tarefa.tipo === "SN EHV-1";
            } else if (filtro === "ELISA") {
                incluirTarefa = tarefa.tipo === "ELISA" ||
                              tarefa.tipo === "ELISA LEUCOSE" ||
                              tarefa.tipo === "ELISA BVDV";
            } else if (filtro === "MOLECULAR") {
                incluirTarefa = tarefa.tipo === "MOLECULAR" ||
                              tarefa.tipo === "PCR";
            } else if (filtro !== "Todos") {
                incluirTarefa = tarefa.tipo === filtro;
            }
            
            if (!incluirTarefa) {
                return; // Pula esta tarefa
            }
            
            // Calcular informações de prazo
            const infoPrazo = calcularPrazoTarefa(tarefa);
            
            const dataRecebimentoStr = tarefa.dataRecebimento?.toDate
                ? formatarDataParaExibicao(tarefa.dataRecebimento.toDate())
                : (tarefa.criadoEm?.toDate ? formatarDataParaExibicao(tarefa.criadoEm.toDate()) : "Data não disponível");

            const statusClass = tarefa.status === 'em-progresso' ? 'em-progresso' : '';
            const concluidoClass = tarefa.status === 'concluido' ? 'concluido' : statusClass;
            
            // Adicionar classes de prazo se não estiver concluída
            let prazoClass = '';
            if (tarefa.status !== 'concluido') {
                if (infoPrazo.vencido) {
                    prazoClass = 'tarefa-vencida';
                } else if (infoPrazo.diasRestantes <= 2) {
                    prazoClass = 'tarefa-urgente';
                }
            }
            
            const combinedClass = `${concluidoClass} ${prazoClass}`.trim();

            const showResultsButton = (tarefa.tipo === "SN" && tarefa.subTipo) || 
                                    (tarefa.tipo === "ELISA" && tarefa.subTipo) ||
                                    (tarefa.tipo === "MOLECULAR" && tarefa.subTipo) ||
                                    tarefa.tipo === "RAIVA" ||
                                    tarefa.tipo === "ICC" ||
                                    // Compatibilidade com dados antigos
                                    tarefa.tipo === "SN IBR" || 
                                    tarefa.tipo === "SN BVDV-1" ||
                                    tarefa.tipo === "SN BVDV-2" ||
                                    tarefa.tipo === "SN HoBi" ||
                                    tarefa.tipo === "SN EHV-1" ||
                                    tarefa.tipo === "ELISA LEUCOSE" ||
                                    tarefa.tipo === "ELISA BVDV" ||
                                    tarefa.tipo === "PCR";

            const amostraItem = document.createElement("div");
            amostraItem.className = `card mb-4 shadow-sm ${combinedClass}`;
            
            // Formatar informações do prazo para exibição
            let prazoTexto = '';
            let prazoIcon = '';
            if (infoPrazo.vencido) {
                prazoTexto = `<span class="text-danger fw-bold">VENCIDO</span> (Prazo: ${infoPrazo.dataPrazo.toLocaleDateString('pt-BR')})`;
                prazoIcon = '<i class="bi bi-exclamation-triangle-fill text-danger me-1"></i>';
            } else if (infoPrazo.diasRestantes <= 2) {
                // Quando faltam 2 dias ou menos - texto amarelo
                const diasText = infoPrazo.tipoPrazo === 'corridos' 
                    ? (infoPrazo.diasRestantes === 1 ? 'dia corrido' : 'dias corridos')
                    : (infoPrazo.diasRestantes === 1 ? 'dia útil' : 'dias úteis');
                prazoTexto = `<span class="text-warning fw-bold">Vence em ${infoPrazo.diasRestantes} ${diasText}</span> (${infoPrazo.dataPrazo.toLocaleDateString('pt-BR')})`;
                prazoIcon = '<i class="bi bi-clock-fill text-warning me-1"></i>';
            } else {
                // Prazo normal - texto verde
                const diasText = infoPrazo.tipoPrazo === 'corridos' 
                    ? (infoPrazo.diasRestantes === 1 ? 'dia corrido' : 'dias corridos')
                    : (infoPrazo.diasRestantes === 1 ? 'dia útil' : 'dias úteis');
                prazoTexto = `<span class="text-success">Vence em ${infoPrazo.diasRestantes} ${diasText}</span> (${infoPrazo.dataPrazo.toLocaleDateString('pt-BR')})`;
                prazoIcon = '<i class="bi bi-clock text-success me-1"></i>';
            }
            
            // Mantenha a estrutura original de botões
            const botoesHtml = `
              <div class="btn-group">
                <button class="btn btn-sm btn-primary btn-progresso" data-id="${doc.id}">
                  <i class="bi bi-arrow-clockwise me-1"></i><span class="btn-text-original">Progresso</span>
                </button>
                
                <button class="btn btn-sm btn-success btn-concluir" data-id="${doc.id}">
                  <i class="bi bi-check2-all me-1"></i>Concluir
                </button>
                
                ${showResultsButton ? `<button class="btn btn-sm btn-warning text-white btn-resultados" data-id="${doc.id}">
                  <i class="bi bi-clipboard-data me-1"></i>Resultado
                </button>` : ''}
                
                <!-- Dropdown "Mais" sem estilos inline -->
                <button type="button" class="btn btn-sm btn-purple dropdown-toggle" 
                        data-bs-toggle="dropdown" aria-expanded="false">
                  <i class="bi bi-three-dots-vertical"></i> <span class="d-none d-sm-inline">Mais</span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                  <li><a class="dropdown-item btn-detalhes" href="#" data-id="${doc.id}">
                      <i class="bi bi-info-circle me-2"></i>Detalhes</a></li>
                  ${tarefa.fichaSV ? `<li><a class="dropdown-item" href="ficha/sv-laudo.html?id=${encodeURIComponent(tarefa.fichaSV)}">
                      <i class="bi bi-file-earmark-medical me-2"></i>Abrir ficha SV</a></li>` : ''}
                  <li><a class="dropdown-item btn-formulario-cobranca" href="#" data-id="${doc.id}">
                      <i class="bi bi-receipt me-2"></i>Formulario de cobranca</a></li>
                  <li><a class="dropdown-item btn-editar" href="#" data-id="${doc.id}">
                      <i class="bi bi-pencil-square me-2"></i>Editar</a></li>
                  <li><hr class="dropdown-divider"></li>
                  <li><a class="dropdown-item text-danger btn-excluir" href="#" data-id="${doc.id}">
                      <i class="bi bi-trash3 me-2"></i>Excluir</a></li>
                </ul>
              </div>
            `;

            // Normalize o tipo para display
            let tipoDisplay = tarefa.tipo;
            if (tipoDisplay === "SN BVDV") {
                tipoDisplay = "SN BVDV-1";
            }

            // E use assim na construção do item
            amostraItem.innerHTML = `
              <div class="card-body">
                <div class="d-flex justify-content-between align-items-center flex-wrap">
                  <div class="mb-2">
                    <h5 class="card-title mb-1 text-success fw-bold">${tarefa.id}</h5>
                    <div class="mb-1"><span class="fw-medium">Tipo:</span> ${tipoDisplay}${tarefa.subTipo ? ` - ${tarefa.subTipo}` : ''}${tarefa.alvo && (tarefa.subTipo === 'PCR' || tarefa.subTipo === 'RT-PCR') ? ` - ${tarefa.alvo}` : ''}</div>
                    <div class="mb-1"><span class="fw-medium">Quantidade:</span> ${tarefa.quantidade || '0'}</div>
                    <div class="mb-1"><span class="fw-medium">Recebimento:</span> ${dataRecebimentoStr}</div>
                    <div class="mb-2">${prazoIcon}<span class="fw-medium">Prazo:</span> ${prazoTexto}</div>
                  </div>
                </div>
                
                <!-- Botões no formato original -->
                ${botoesHtml}
              </div>
            `;

            muralList.appendChild(amostraItem);
        });

        // Adiciona event listeners para os botões
        document.querySelectorAll('.btn-progresso').forEach(btn => {
            btn.addEventListener('click', async function() {
                // Salvar largura original do botão
                const originalWidth = this.offsetWidth;
                this.style.width = originalWidth + "px";
                
                // Desativar o botão durante a operação
                this.disabled = true;
                
                try {
                    // Chamar a função original
                    await window.marcarProgresso(this.dataset.id);
                    
                    // Atualizar apenas o texto dentro do span
                    const textSpan = this.querySelector('.btn-text-original');
                    if (textSpan) {
                        const tarefaRef = doc(db, "tarefas", this.dataset.id);
                        const tarefaSnap = await getDoc(tarefaRef);
                        
                        
                    }
                } catch (error) {
                    console.error("Erro ao atualizar status:", error);
                } finally {
                    // Reativar o botão
                    this.disabled = false;
                    
                    // Remover largura fixa após um momento
                    setTimeout(() => {
                        this.style.width = "";
                    }, 500);
                }
            });
        });

        document.querySelectorAll('.btn-concluir').forEach(btn => {
            btn.addEventListener('click', () => window.concluirTarefa(btn.dataset.id));
        });

        document.querySelectorAll('.btn-resultados').forEach(btn => {
            btn.addEventListener('click', () => window.registrarResultado(btn.dataset.id));
        });

        document.querySelectorAll('.btn-detalhes').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                window.mostrarDetalhes(btn.dataset.id);
            });
        });

        document.querySelectorAll('.btn-formulario-cobranca').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                window.gerarFormularioCobrancaMural(btn.dataset.id);
            });
        });

        // Atualize esta parte na função carregarTarefas
        document.querySelectorAll('.btn-editar').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                window.editarTarefaModal(btn.dataset.id);
            });
        });

        document.querySelectorAll('.btn-excluir').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                window.excluirTarefa(btn.dataset.id);
            });
        });

    } catch (error) {
        console.error("Erro ao carregar tarefas:", error);
        const muralList = document.getElementById("mural-list");
        if (muralList) {
            muralList.innerHTML = `
                <p class="text-danger">Erro ao carregar tarefas: ${error.message}</p>
                <p>Verifique o console para mais detalhes.</p>
            `;
        }
    } finally {
        esconderLoading();
    }
}

// Expor funções no objeto window para acessibilidade
window.carregarTarefas = carregarTarefas;

window.gerarFormularioCobrancaMural = async (id) => {
    mostrarLoading();
    try {
        const tarefaRef = doc(db, "tarefas", id);
        const tarefaSnap = await getDoc(tarefaRef);

        if (!tarefaSnap.exists()) throw new Error("Tarefa nao encontrada");

        await gerarFormularioCobrancaWord(tarefaSnap.data());
        mostrarFeedback("Formulario de cobranca em Word baixado com sucesso!", "success");
    } catch (error) {
        console.error("Erro ao gerar formulario de cobranca:", error);
        mostrarFeedback(`Erro: ${error.message}`, "error");
    } finally {
        esconderLoading();
    }
};

// Atualize a função marcarProgresso
window.marcarProgresso = async (id) => {
    mostrarLoading();
    try {
        // Encontra o botão e o card
        const botao = document.querySelector(`button.btn-progresso[data-id="${id}"]`);
        
        // Adiciona classes temporárias em vez de manipular estilos inline
        if (botao) {
            botao.disabled = true;
            botao.classList.add('processing');
        }
        
        // O resto da função permanece o mesmo...
        const tarefaRef = doc(db, "tarefas", id);
        const tarefaSnap = await getDoc(tarefaRef);
        
        if (!tarefaSnap.exists()) throw new Error("Tarefa não encontrada");
        
        const tarefa = tarefaSnap.data();
        const novoStatus = tarefa.status === 'em-progresso' ? 'pendente' : 'em-progresso';
        
        // Atualiza o card imediatamente na UI
        const cardElement = document.querySelector(`[data-id="${id}"]`).closest('.card');
        if (cardElement) {
            if (novoStatus === 'em-progresso') {
                cardElement.classList.add('em-progresso');
            } else {
                cardElement.classList.remove('em-progresso');
            }
        }
        
        // Salva no Firestore
        await updateDoc(tarefaRef, { 
            status: novoStatus,
            atualizadoEm: Timestamp.now()
        });
        
        mostrarFeedback(`Tarefa atualizada com sucesso!`, "success");
    } catch (error) {
        console.error("Erro ao atualizar status:", error);
        mostrarFeedback(`Erro: ${error.message}`, "error");
    } finally {
        esconderLoading();
        
        // Remove classes temporárias após um delay
        setTimeout(() => {
            const botao = document.querySelector(`button.btn-progresso[data-id="${id}"]`);
            if (botao) {
                botao.disabled = false;
                botao.classList.remove('processing');
            }
        }, 500);
    }
};

// Função para concluir tarefa
window.concluirTarefa = async (id) => {
    if (!confirm("Tem certeza que deseja concluir esta tarefa?")) return;
    
    mostrarLoading();
    try {
        const tarefaRef = doc(db, "tarefas", id);
        const tarefaSnap = await getDoc(tarefaRef);
        
        if (!tarefaSnap.exists()) throw new Error("Tarefa não encontrada");
        
        const tarefa = tarefaSnap.data();
        await addDoc(collection(db, "historico"), {
            ...tarefa,
            dataConclusao: Timestamp.now(),
            concluidoPor: auth.currentUser.uid
            // criadoEm já está preservado com o mesmo valor de dataRecebimento
        });
        
        await deleteDoc(tarefaRef);
        carregarTarefas();
        mostrarFeedback("Tarefa concluída com sucesso!", "success");
    } catch (error) {
        console.error("Erro ao concluir:", error);
        mostrarFeedback(`Erro: ${error.message}`, "error");
    } finally {
        esconderLoading();
    }
};

// Função para excluir tarefa
window.excluirTarefa = async (id) => {
    if (!confirm("Tem certeza que deseja excluir esta tarefa?")) return;
    
    mostrarLoading();
    try {
        await deleteDoc(doc(db, "tarefas", id));
        carregarTarefas();
        mostrarFeedback("Tarefa excluída com sucesso!", "success");
    } catch (error) {
        console.error("Erro ao excluir:", error);
        mostrarFeedback(`Erro: ${error.message}`, "error");
    } finally {
        esconderLoading();
    }
};

// Função para editar tarefa
window.editarTarefaModal = async (id) => {
    mostrarLoading();
    try {
        const tarefaRef = doc(db, "tarefas", id);
        const tarefaSnap = await getDoc(tarefaRef);
        
        if (!tarefaSnap.exists()) throw new Error("Tarefa não encontrada");
        
        const tarefa = tarefaSnap.data();
        const modal = document.getElementById('tarefa-modal');
        const modalTitle = modal.querySelector('.modal-title');
        
        // Configurar título
        modalTitle.innerHTML = '<i class="bi bi-pencil-square"></i> Editar Tarefa';
        
        // Preencher o formulário com dados existentes
        document.getElementById("id-modal").value = tarefa.id;
        document.getElementById("tipo-modal").value = tarefa.tipo;
        document.getElementById("quantidade-modal").value = tarefa.quantidade;
        
        // Mostrar/ocultar campos condicionais
        const tipo = tarefa.tipo;
        if (tipo === "VACINA") {
            document.getElementById("gramatura-container-modal").style.display = "block";
            document.getElementById("gramatura-modal").value = tarefa.gramatura || "";
        } else {
            document.getElementById("gramatura-container-modal").style.display = "none";
        }
        
        // Controlar e preencher containers dos submenus
        if (tipo === "MOLECULAR") {
            document.getElementById("pcr-container-modal").style.display = "block";
            document.getElementById("pcr-tipo-modal").value = tarefa.subTipo || "";
        } else {
            document.getElementById("pcr-container-modal").style.display = "none";
        }
        
        if (tipo === "SN") {
            document.getElementById("sn-container-modal").style.display = "block";
            document.getElementById("sn-tipo-modal").value = tarefa.subTipo || "";
        } else {
            document.getElementById("sn-container-modal").style.display = "none";
        }
        
        if (tipo === "ELISA") {
            document.getElementById("elisa-container-modal").style.display = "block";
            document.getElementById("elisa-tipo-modal").value = tarefa.subTipo || "";
        } else {
            document.getElementById("elisa-container-modal").style.display = "none";
        }
        
        const dataRecebimento = (tarefa.dataRecebimento?.toDate && tarefa.dataRecebimento.toDate()) ||
                                (tarefa.criadoEm?.toDate && tarefa.criadoEm.toDate()) ||
                                null;
        if (dataRecebimento) {
            // Já está em horário local; NÃO subtrair timezoneOffset novamente para evitar -3h
            const local = dataRecebimento; // Timestamp.toDate() retorna Date no fuso local
            const yyyy = local.getFullYear();
            const mm = String(local.getMonth() + 1).padStart(2, '0');
            const dd = String(local.getDate()).padStart(2, '0');
            document.getElementById("data-modal").value = `${yyyy}-${mm}-${dd}`;
            const horaEl = document.getElementById('hora-modal');
            if (horaEl) {
                const hh = String(local.getHours()).padStart(2, '0');
                const min = String(local.getMinutes()).padStart(2, '0');
                horaEl.value = `${hh}:${min}`;
            }
        }
        
        document.getElementById("observacoes-modal").value = tarefa.observacoes || "";
        document.getElementById("material-recebido-modal").value = tarefa.materialRecebido || "";

        if (tarefa.proprietario) {
            document.getElementById("proprietario-nome-modal").value = tarefa.proprietario.nome || "";
            document.getElementById("proprietario-municipio-modal").value = tarefa.proprietario.municipio || "";
            document.getElementById("proprietario-contato-modal").value = tarefa.proprietario.contato || "";
        }
        
        if (tarefa.veterinario) {
            document.getElementById("veterinario-nome-modal").value = tarefa.veterinario.nome || "";
            document.getElementById("veterinario-crmv-modal").value = tarefa.veterinario.crmv || "";
            document.getElementById("veterinario-municipio-modal").value = tarefa.veterinario.municipio || "";
            document.getElementById("veterinario-contato-modal").value = tarefa.veterinario.contato || "";

        }
        
        // Configurar todos os menus flutuantes
        configurarMenusFlutantes();

        // Configurar o botão salvar para atualizar tarefa
        document.getElementById('salvar-tarefa-modal').onclick = async () => {
            try {
                mostrarLoading();
                
                // NOVO: Capturar os valores atuais dos filtros antes da atualização
                const filtroTipoAtual = document.getElementById("filtro-tipo").value;
                const filtroOrdemAtual = document.getElementById("filtro-ordem").value;
                
                // Obter valores dos campos
                const tipoValue = document.getElementById("tipo-modal").value;
                const updateData = {
                    id: document.getElementById("id-modal").value,
                    tipo: tipoValue,
                    quantidade: parseInt(document.getElementById("quantidade-modal").value),
                    atualizadoEm: Timestamp.now(),
                    observacoes: document.getElementById("observacoes-modal").value.trim(),
                    materialRecebido: document.getElementById("material-recebido-modal").value.trim()
                };

                // Adicionar campos condicionais
                if (tipoValue === "VACINA") {
                    const gramaturaInput = document.getElementById("gramatura-modal");
                    updateData.gramatura = gramaturaInput ? parseFloat(gramaturaInput.value) || null : null;
                } else {
                    updateData.gramatura = null;
                }

                // Determinar subtipo baseado no tipo principal
                let subTipo = null;
                if (tipoValue === "MOLECULAR") {
                    const pcrTipoInput = document.getElementById("pcr-tipo-modal");
                    subTipo = pcrTipoInput ? pcrTipoInput.value.trim() : null;
                } else if (tipoValue === "SN") {
                    const snTipoInput = document.getElementById("sn-tipo-modal");
                    subTipo = snTipoInput ? snTipoInput.value.trim() : null;
                } else if (tipoValue === "ELISA") {
                    const elisaTipoInput = document.getElementById("elisa-tipo-modal");
                    subTipo = elisaTipoInput ? elisaTipoInput.value.trim() : null;
                }
                
                updateData.subTipo = subTipo;
                
                // Capturar possível alteração de data/hora de recebimento
                const dataVal = document.getElementById('data-modal').value;
                const horaVal = document.getElementById('hora-modal')?.value;
                let recebimentoAtual = (tarefa.dataRecebimento?.toDate && tarefa.dataRecebimento.toDate()) ||
                                       (tarefa.criadoEm?.toDate && tarefa.criadoEm.toDate()) || new Date();
                if (dataVal) {
                    // Mesma correção de fuso: interpretar como local
                    const base = parseDateInputLocal(dataVal) || new Date();
                    if (horaVal) {
                        const [h, m] = horaVal.split(':').map(Number);
                        base.setHours(h || 0, m || 0, 0, 0);
                    }
                    recebimentoAtual = base;
                }

                // Determinar prazo do tipo/subtipo atual e recalcular com a data/hora escolhida
                const prazoInfoAtual = obterPrazoDiasTeste(tipoValue, subTipo);
                let novaDataPrazo;
                const deltaEdit = Math.max(prazoInfoAtual.dias - 1, 0);
                if (prazoInfoAtual.tipo === 'corridos') {
                    novaDataPrazo = adicionarDiasCorridos(recebimentoAtual, deltaEdit);
                } else {
                    novaDataPrazo = adicionarDiasUteis(recebimentoAtual, deltaEdit);
                }
                updateData.dataPrazo = Timestamp.fromDate(novaDataPrazo);
                updateData.diasPrazo = prazoInfoAtual.dias;
                updateData.tipoPrazo = prazoInfoAtual.tipo;
                // Não atualizar criadoEm para preservar a hora/data original de criação
                // Apenas manter/atualizar dataRecebimento (campo editável)
                updateData.dataRecebimento = Timestamp.fromDate(recebimentoAtual);
                
                // Remover campos antigos se existirem
                updateData.pcrTipo = null;

                // Atualizar campos de proprietário e veterinário
                const proprietarioNome = document.getElementById("proprietario-nome-modal").value.trim();
                const proprietarioMunicipio = document.getElementById("proprietario-municipio-modal").value.trim();
                const proprietarioContato = document.getElementById("proprietario-contato-modal").value.trim();
                
                updateData.proprietario = {
                    nome: proprietarioNome,
                    municipio: proprietarioMunicipio,
                    contato: proprietarioContato
                };

                const veterinarioNome = document.getElementById("veterinario-nome-modal").value.trim();
                const veterinarioCrmv = document.getElementById("veterinario-crmv-modal").value.trim();
                const veterinarioMunicipio = document.getElementById("veterinario-municipio-modal").value.trim();
                const veterinarioContato = document.getElementById("veterinario-contato-modal").value.trim();
                
                updateData.veterinario = {
                    nome: veterinarioNome,
                    crmv: veterinarioCrmv,
                    municipio: veterinarioMunicipio,
                    contato: veterinarioContato
                };

                // Atualizar a tarefa
                await updateDoc(tarefaRef, updateData);
                
                // Fechar o modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('tarefa-modal'));
                if (modal) modal.hide();
                
                // MODIFICADO: Carregar tarefas mantendo os filtros atuais
                carregarTarefas(filtroTipoAtual, filtroOrdemAtual);
                mostrarFeedback("Tarefa atualizada com sucesso!", "success");
            } catch (error) {
                console.error("Erro ao atualizar:", error);
                mostrarFeedback(`Erro: ${error.message}`, "error");
            } finally {
                esconderLoading();
            }
        };
        
        // Abrir o modal
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();
        
    } catch (error) {
        console.error("Erro ao editar:", error);
        mostrarFeedback(`Erro: ${error.message}`, "error");
    } finally {
        esconderLoading();
    }
};

// Função para mostrar detalhes da tarefa
window.mostrarDetalhes = async (id) => {
    mostrarLoading();
    try {
        const docRef = doc(db, "tarefas", id);
        const docSnap = await getDoc(docRef);

        if (!docSnap.exists()) throw new Error("Tarefa não encontrada");
        
        const tarefa = docSnap.data();
        let siglaUsuario = "N/A";
        if (tarefa.siglaResponsavel && tarefa.siglaResponsavel !== "N/A") {
            siglaUsuario = tarefa.siglaResponsavel;
        } else if (tarefa.criadoPor) {
            // Busca a sigla do usuário no banco, se não estiver salva na tarefa
            try {
                const userRef = doc(db, "usuarios", tarefa.criadoPor);
                const userSnap = await getDoc(userRef);
                if (userSnap.exists()) {
                    siglaUsuario = userSnap.data().sigla || "N/A";
                }
            } catch (e) {
                // Se der erro, mantém "N/A"
            }
        }

        // Formatar data/hora de recebimento (registro)
        const dataRecebimento = tarefa.criadoEm?.toDate
            ? formatarDataParaExibicao(tarefa.criadoEm.toDate())
            : "Data não disponível";

        // Calcular informações de prazo
        const infoPrazo = calcularPrazoTarefa(tarefa);
        
        // Formatar informações do prazo para exibição
        let prazoTexto = '';
        let prazoIcon = '';
        if (infoPrazo.vencido) {
            prazoTexto = `<span class="text-danger fw-bold">VENCIDO</span> (${infoPrazo.dataPrazo.toLocaleDateString('pt-BR')})`;
            prazoIcon = '<i class="bi bi-exclamation-triangle-fill text-danger me-2"></i>';
        } else if (infoPrazo.diasRestantes <= 2) {
            // Quando faltam 2 dias ou menos - texto amarelo
            const diasText = infoPrazo.tipoPrazo === 'corridos' 
                ? (infoPrazo.diasRestantes === 1 ? 'dia corrido' : 'dias corridos')
                : (infoPrazo.diasRestantes === 1 ? 'dia útil' : 'dias úteis');
            prazoTexto = `<span class="text-warning fw-bold">${infoPrazo.diasRestantes} ${diasText} restantes</span> (${infoPrazo.dataPrazo.toLocaleDateString('pt-BR')})`;
            prazoIcon = '<i class="bi bi-clock-fill text-warning me-2"></i>';
        } else {
            // Prazo normal - texto verde
            const diasText = infoPrazo.tipoPrazo === 'corridos' 
                ? (infoPrazo.diasRestantes === 1 ? 'dia corrido' : 'dias corridos')
                : (infoPrazo.diasRestantes === 1 ? 'dia útil' : 'dias úteis');
            prazoTexto = `<span class="text-success fw-bold">${infoPrazo.diasRestantes} ${diasText} restantes</span> (${infoPrazo.dataPrazo.toLocaleDateString('pt-BR')})`;
            prazoIcon = '<i class="bi bi-clock text-success me-2"></i>';
        }

        // Remove modal antigo se existir
        let modalElement = document.getElementById("modal-detalhes");
        if (modalElement) modalElement.remove();

        // Status badge
        let statusBadge = "";
        if (tarefa.status === 'em-progresso') {
            statusBadge = '<span class="badge bg-primary">Em Progresso</span>';
        } else if (tarefa.status === 'concluido') {
            statusBadge = '<span class="badge bg-success">Concluído</span>';
        } else {
            statusBadge = '<span class="badge bg-warning text-dark">Pendente</span>';
        }

        // Modal HTML igual ao do histórico
        const modalContent = `
            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="bi bi-info-circle-fill text-success me-2"></i>
                    <span class="fw-bold text-success">Detalhes da Tarefa</span>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body p-4">
                <div class="card border-0 mb-3 shadow-sm">
                    <div class="card-body">
                        <h6 class="card-subtitle mb-3 text-success fw-bold">
                            <i class="bi bi-card-heading me-2"></i>Informações Básicas
                        </h6>
                        <div class="row mb-2">
                            <div class="col-5 text-muted">ID:</div>
                            <div class="col-7 fw-medium">${tarefa.id || 'N/A'}</div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-5 text-muted">Tipo:</div>
                            <div class="col-7 fw-medium">${tarefa.tipo || 'N/A'}${tarefa.subTipo ? ` - ${tarefa.subTipo}` : ''}</div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-5 text-muted">Quantidade:</div>
                            <div class="col-7 fw-medium">${tarefa.quantidade || '0'} ${tarefa.tipo === "VACINA" 
                                ? `vacinas${tarefa.gramatura ? ` (${tarefa.gramatura}g)` : ''}` 
                                : "amostras"}</div>
                        </div>
                    </div>
                </div>
                <div class="card border-0 mb-3 shadow-sm">
                    <div class="card-body">
                        <h6 class="card-subtitle mb-3 text-success fw-bold">
                            <i class="bi bi-people-fill me-2"></i>Contatos
                        </h6>
                        <div class="row mb-2">
                            <div class="col-5 text-muted">Proprietário:</div>
                            <div class="col-7 fw-medium">${typeof tarefa.proprietario === 'object' 
                                ? tarefa.proprietario?.nome || 'N/A'
                                : tarefa.proprietario || 'N/A'}</div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-5 text-muted">Veterinário:</div>
                            <div class="col-7 fw-medium">${typeof tarefa.veterinario === 'object'
                                ? tarefa.veterinario?.nome || 'N/A'
                                : tarefa.veterinario || 'N/A'}</div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-5 text-muted">CRMV:</div>
                            <div class="col-7 fw-medium">${typeof tarefa.veterinario === 'object'
                                ? tarefa.veterinario?.crmv || 'N/A'
                                : 'N/A'}</div>
                        </div>
                    </div>
                </div>
                <div class="card border-0 mb-3 shadow-sm">
                    <div class="card-body">
                        <h6 class="card-subtitle mb-3 text-success fw-bold">
                            <i class="bi bi-calendar3 me-2"></i>Status e Datas
                        </h6>
                        <div class="row mb-2">
                            <div class="col-5 text-muted">Status:</div>
                            <div class="col-7">${statusBadge}</div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-5 text-muted">Recebimento:</div>
                            <div class="col-7 fw-medium">${dataRecebimento}</div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-5 text-muted">Responsável:</div>
                            <div class="col-7 fw-medium">${siglaUsuario}</div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-12">
                                <div class="card border-0">
                                    <div class="card-body p-3">
                                        <div class="d-flex align-items-center">
                                            ${prazoIcon}
                                            <span class="fw-medium">Prazo: ${prazoTexto}</span>
                                        </div>
                                        <small class="text-muted">Prazo: ${infoPrazo.diasUteis} dias úteis</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                ${tarefa.materialRecebido ? `
                <div class="card border-0 mb-3 shadow-sm">
                    <div class="card-body">
                        <h6 class="card-subtitle mb-3 text-success fw-bold">
                            <i class="bi bi-box-seam me-2"></i>Material Recebido
                        </h6>
                        <div class="bg-light p-3 rounded" style="white-space: pre-wrap; word-break: break-word; font-size: 0.95rem;">
${tarefa.materialRecebido}
                        </div>
                    </div>
                </div>` : ''}
                ${tarefa.observacoes ? `
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h6 class="card-subtitle mb-3 text-success fw-bold">
                            <i class="bi bi-card-text me-2"></i>Observações
                        </h6>
                        <div class="bg-light p-3 rounded" style="white-space: pre-wrap; word-break: break-word; font-size: 0.95rem;">
${tarefa.observacoes}
                        </div>
                    </div>
                </div>` : ''}
            </div>
        `;

        // Cria e mostra o modal
        const modalDiv = document.createElement("div");
        modalDiv.className = "modal fade";
        modalDiv.id = "modal-detalhes";
        modalDiv.tabIndex = -1;
        modalDiv.innerHTML = `
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow">
                    ${modalContent}
                </div>
            </div>
        `;
        document.body.appendChild(modalDiv);

        const modal = new bootstrap.Modal(modalDiv);
        modal.show();

        modalDiv.addEventListener('hidden.bs.modal', function () {
            modalDiv.remove();
        });

    } catch (error) {
        console.error("Erro ao mostrar detalhes:", error);
        mostrarFeedback(`Erro: ${error.message}`, "error");
    } finally {
        esconderLoading();
    }
};

// Função para registrar resultados
window.registrarResultado = async (id) => {
    mostrarLoading();
    try {
        const tarefaRef = doc(db, "tarefas", id);
        const tarefaSnap = await getDoc(tarefaRef);
        
        if (!tarefaSnap.exists()) throw new Error("Tarefa não encontrada");
        
        const tarefa = tarefaSnap.data();
        const tipo = (tarefa.tipo || "").trim().toUpperCase();

        if (tipo === "ELISA") {
            await registrarResultadoELISA(id);
            return;
        }
        if (tipo === "SN" || tipo.includes("SN ")) {
            await registrarResultadoSN(id);
            return;
        }
        if (tipo === "MOLECULAR" || tipo === "PCR") {
            await registrarResultadoMolecular(id);
            return;
        }
        if (tipo === "RAIVA") {
            await registrarResultadoRAIVA(id);
            return;
        }
        if (tipo === "ICC") {
            await registrarResultadoICC(id);
            return;
        }

        mostrarFeedback("Este tipo de tarefa não possui resultados específicos", "error");
    } catch (error) {
        console.error("Erro ao registrar resultado:", error);
        mostrarFeedback(`Erro: ${error.message}`, "error");
    } finally {
        esconderLoading();
    }
};

// Função para carregar proprietários sugeridos
async function carregarProprietariosSugeridos() {
    try {
        const proprietariosRef = collection(db, "proprietarios");
        const querySnapshot = await getDocs(proprietariosRef);
        const datalist = document.getElementById("proprietarios-list-modal");
        
        if (!datalist) return;
        
        // Limpa a lista atual
        datalist.innerHTML = "";
        
        // Adiciona cada proprietário como uma opção
        querySnapshot.forEach((doc) => {
            const proprietario = doc.data().nome;
            const option = document.createElement("option");
            option.value = proprietario;
            datalist.appendChild(option);
        });
    } catch (error) {
        console.error("Erro ao carregar proprietários:", error);
    }
}



// Atualizar inicialização para usar o modal
document.addEventListener("DOMContentLoaded", () => {
    try {
        // Proteção contra loading infinito (recuperada do evento anterior)
        setTimeout(() => {
            const loading = document.getElementById("loading");
            if (loading && loading.style.display === "flex") {
                console.warn("Loading timeout - forçando ocultação");
                loading.style.display = "none";
            }
        }, 10000); // 10 segundos de timeout
        
        // Botões e eventos
        const adicionarTarefaBtn = document.getElementById("adicionar-tarefa");
        const tipoInput = document.getElementById("tipo-modal");
        const filtroOrdemSelect = document.getElementById("filtro-ordem");
        const filtroTipoSelect = document.getElementById("filtro-tipo");
        const hubBtn = document.getElementById("hub-button");
        const historicoBtn = document.getElementById("historico-button");
        
        if (adicionarTarefaBtn) {
            adicionarTarefaBtn.addEventListener('click', () => {
                prepararModalAdicao();
                const modal = new bootstrap.Modal(document.getElementById('tarefa-modal'));
                modal.show();
            });
        }
        
        // Adicione isso dentro do evento DOMContentLoaded

        if (filtroTipoSelect) {
            filtroTipoSelect.addEventListener('change', function() {
                const filtroTipo = this.value;
                const filtroOrdem = document.getElementById("filtro-ordem").value;
                carregarTarefas(filtroTipo, filtroOrdem);
            });
        }

        if (filtroOrdemSelect) {
            filtroOrdemSelect.addEventListener('change', function() {
                const filtroTipo = document.getElementById("filtro-tipo").value;
                const filtroOrdem = this.value;
                carregarTarefas(filtroTipo, filtroOrdem);
            });
        }
        
        
        // Inicializar autenticação e carregar dados (recuperada do primeiro evento)
        mostrarLoading();
        onAuthStateChanged(auth, async (user) => {
            try {
                if (user) {
                    await Promise.all([
                        carregarProprietariosSugeridos(),
                        carregarTarefas()
                    ]);
                    
                    // Atualizar prazos de tarefas existentes (executar apenas uma vez)
                    try {
                        await atualizarPrazosExistentes();
                    } catch (error) {
                        console.warn("Aviso ao atualizar prazos:", error);
                    }
                    
                    esconderLoading();
                } else {
                    esconderLoading();
                    window.location.href = "../index.html";
                }
            } catch (error) {
                console.error("Erro na verificação de autenticação:", error);
                esconderLoading();
            }
        });

        // Adicionar event listeners para os botões de navegação
        if (hubBtn) {
            hubBtn.addEventListener('click', () => {
                window.location.href = "hub.html";
            });
        }

        if (historicoBtn) {
            historicoBtn.addEventListener('click', () => {
                window.location.href = "historico.html";
            });
        }

        // Correção para o botão "Voltar ao Hub"
        const voltarHubBtn = document.getElementById("voltar-hub");
        if (voltarHubBtn) {
            voltarHubBtn.addEventListener('click', () => {
                window.location.href = "hub.html";
            });
        }
    } catch (error) {
        console.error("Erro na inicialização:", error);
        esconderLoading();
    }
});

// No modal
document.querySelector("#tarefa-modal .btn-close").addEventListener("click", () => {
  const modal = bootstrap.Modal.getInstance(document.getElementById('tarefa-modal'));
  if (modal) modal.hide();
});

document.querySelector("#tarefa-modal .modal-footer .mural-btn-outline").addEventListener("click", () => {
  const modal = bootstrap.Modal.getInstance(document.getElementById('tarefa-modal'));
  if (modal) modal.hide();
});

window.editarTarefa = async (id) => {
  // Remova referências a mostrarFormulario(true);
  // Substitua por:
  window.editarTarefaModal(id);
};

// Assegurar que as funções do módulo são acessíveis globalmente
window.mostrarFeedback = mostrarFeedback;
window.esconderLoading = esconderLoading;
window.mostrarLoading = mostrarLoading;
